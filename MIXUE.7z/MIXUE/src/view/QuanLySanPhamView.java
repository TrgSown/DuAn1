/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package view;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.table.DefaultTableModel;
import model.SanPhamChiTiet;
import model.ThuocTinh;
import repository.SanPhamChiTietRepository;
import repository.SanPhamRepository;
import repository.ThuocTinhRepository;


/**
 *
 * @author ADMIN
 */
public class QuanLySanPhamView extends javax.swing.JPanel {
   //SanPhamRepository spRepo = new SanPhamRepository();
    SanPhamChiTietRepository spctRepo = new SanPhamChiTietRepository();
    ThuocTinhRepository ttRepo = new ThuocTinhRepository();
    List<SanPhamChiTiet> lst = new ArrayList<>();
    List<ThuocTinh> lstThuocTinh = new ArrayList<>();
    DefaultTableModel model;
    DefaultTableModel modelThuocTinh;
    String loaiThuocTinhHienTai = "Kích thước"; // Mặc định
    /**
     * Creates new form QuanLySanPhamView
     */
    public QuanLySanPhamView() {
        initComponents();
        model = (DefaultTableModel) tblThongTinCT.getModel();
        modelThuocTinh = (DefaultTableModel) tblThuocTinhSP.getModel();
        // Mặc định chỉ hiển thị sản phẩm còn hàng
        fillTableSP(spctRepo.getAllActive());
        fillTableThuocTinh();
        fillToComboboxKT();
        fillToComboboxCL();
        
        // Thêm sự kiện cho checkbox hiển thị sản phẩm đã ẩn
        jCheckBox1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jCheckBox1ActionPerformed(evt);
            }
        });
        
        // Thêm sự kiện cho các radiobutton thuộc tính
        btnKichThuoc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnKichThuocActionPerformed(evt);
            }
        });
        
        btnChatLieu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChatLieuActionPerformed(evt);
            }
        });
        
        btnTenLoaiSP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTenLoaiSPActionPerformed(evt);
            }
        });
        // Thêm sự kiện cho bảng thuộc tính
        tblThuocTinhSP.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblThuocTinhSPMouseClicked(evt);
            }
        });
        
        // Thêm sự kiện cho các nút thuộc tính
        btnThemTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemTTActionPerformed(evt);
            }
        });
        
        btnSuaTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaTTActionPerformed(evt);
            }
        });
        
        btnXoaTT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXoaTTActionPerformed(evt);
            }
        });
    }
    
    // Hàm xử lý sự kiện checkbox hiển thị sản phẩm đã ẩn
    private void jCheckBox1ActionPerformed(java.awt.event.ActionEvent evt) {
        if (jCheckBox1.isSelected()) {
            // Hiển thị tất cả sản phẩm (cả đã ẩn)
            fillTableSP(spctRepo.getAll());
        } else {
            // Chỉ hiển thị sản phẩm còn hàng (trạng thái = 1)
            fillTableSP(spctRepo.getAllActive());
        }
    }
    public void fillTableSP(ArrayList<SanPhamChiTiet> danhSach){
        lst = danhSach; // Cập nhật lại lst để đồng bộ với bảng
        model.setRowCount(0);
        for (SanPhamChiTiet spct : danhSach) {
            model.addRow(new Object[]{
                spct.getSanPhamChiTietID(),
                spct.getMaSPCT(),
                spct.getTenSP(),
                spct.getGiaBan(),
                spct.getSoLuong(),
                getTenKichThuoc(spct.getKichThuocID()), // Hiển thị tên kích thước
                getTenChatLieu(spct.getChatLieuID()), // Hiển thị tên chất liệu
                spct.getTrangThai()==1?"Còn hàng":"Hết hàng",
                spct.getMoTa()
            });
        }
    }
    
    // Hàm chuyển đổi ID kích thước thành tên
    private String getTenKichThuoc(int kichThuocID) {
        switch (kichThuocID) {
            case 1:
                return "S";
            case 2:
                return "M";
            case 3:
                return "L";
            default:
                return "S";
        }
    }
    
    // Hàm chuyển đổi ID chất liệu thành tên
    private String getTenChatLieu(int chatLieuID) {
        switch (chatLieuID) {
            case 1:
                return "Chocolate";
            case 2:
                return "Trân Châu Đường Đen";
            case 3:
                return "Sữa kem";
            case 4:
                return "Hồng trà";
            default:
                return "Chocolate";
        }
    }
    
    public void fillTableThuocTinh(){
        lstThuocTinh = ttRepo.getByLoai(loaiThuocTinhHienTai);
        modelThuocTinh.setRowCount(0);
        int stt = 1;
        for (ThuocTinh tt : lstThuocTinh) {
            modelThuocTinh.addRow(new Object[]{
                stt++,
                tt.getLoaiThuocTinh(),
                tt.getTenThuocTinh()
            });
        }
    }
    
    public void fillToComboboxKT(){
         DefaultComboBoxModel model = (DefaultComboBoxModel) cboKichThuoc.getModel();
          model.removeAllElements();
          // Thêm các kích thước cố định: 1=S, 2=M, 3=L
          model.addElement("S");
          model.addElement("M");
          model.addElement("L");
    }
    
    public void fillToComboboxCL(){
         DefaultComboBoxModel model = (DefaultComboBoxModel) cboChatLieu.getModel();
          model.removeAllElements();
          // Thêm các chất liệu cố định: 1=Chocolate, 2=Trân Châu Đường Đen, 3=Sữa kem, 4=Hồng trà
          model.addElement("Chocolate");
          model.addElement("Trân Châu Đường Đen");
          model.addElement("Sữa kem");
          model.addElement("Hồng trà");
    }
        
     public void timKiem(ActionEvent e){
         String keyWord = txtTimKiem.getText().trim().toLowerCase();
         DefaultTableModel model = (DefaultTableModel) tblThongTinCT.getModel();
         model.setRowCount(0);
         
         // Nếu từ khóa rỗng, hiển thị tất cả sản phẩm
         if (keyWord.isEmpty()) {
             if (jCheckBox1.isSelected()) {
                 fillTableSP(spctRepo.getAll());
             } else {
                 fillTableSP(spctRepo.getAllActive());
             }
             return;
         }
         
         // Lọc sản phẩm theo từ khóa tìm kiếm
         ArrayList<SanPhamChiTiet> filteredList = new ArrayList<>();
         List<SanPhamChiTiet> searchList;
         
         // Chọn danh sách tìm kiếm dựa trên checkbox
         if (jCheckBox1.isSelected()) {
             searchList = spctRepo.getAll();
         } else {
             searchList = spctRepo.getAllActive();
         }
         
         for (SanPhamChiTiet spct : searchList) {
             // Tìm kiếm theo mã sản phẩm, tên sản phẩm, hoặc mô tả
             boolean match = false;
             
             if (spct.getMaSPCT() != null && spct.getMaSPCT().toLowerCase().contains(keyWord)) {
                 match = true;
             }
             if (spct.getTenSP() != null && spct.getTenSP().toLowerCase().contains(keyWord)) {
                 match = true;
             }
             if (spct.getMoTa() != null && spct.getMoTa().toLowerCase().contains(keyWord)) {
                 match = true;
             }
             
             // Tìm kiếm theo tên kích thước
             String tenKichThuoc = getTenKichThuoc(spct.getKichThuocID());
             if (tenKichThuoc != null && tenKichThuoc.toLowerCase().contains(keyWord)) {
                 match = true;
             }
             
             // Tìm kiếm theo tên chất liệu
             String tenChatLieu = getTenChatLieu(spct.getChatLieuID());
             if (tenChatLieu != null && tenChatLieu.toLowerCase().contains(keyWord)) {
                 match = true;
             }
             
             if (match) {
                 filteredList.add(spct);
             }
         }
         
         // Hiển thị kết quả tìm kiếm
         fillTableSP(filteredList);
     }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        buttonGroup2 = new javax.swing.ButtonGroup();
        tabs = new javax.swing.JTabbedPane();
        ThongTin = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        txtMaSP = new javax.swing.JTextField();
        txtTenSP = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtDonGia = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtSoLuong = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        cboKichThuoc = new javax.swing.JComboBox<>();
        cboChatLieu = new javax.swing.JComboBox<>();
        jLabel10 = new javax.swing.JLabel();
        txtMota = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rdoCon = new javax.swing.JRadioButton();
        rdoHet = new javax.swing.JRadioButton();
        jLabel4 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblThongTinCT = new javax.swing.JTable();
        txtTimKiem = new javax.swing.JTextField();
        btnSearch = new javax.swing.JButton();
        btnThemCT = new javax.swing.JButton();
        btnSuaCT = new javax.swing.JButton();
        btnMoiCT = new javax.swing.JButton();
        btnAn = new javax.swing.JButton();
        jCheckBox1 = new javax.swing.JCheckBox();
        ThuocTinh = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txtTenThuocTinh = new javax.swing.JTextField();
        btnKichThuoc = new javax.swing.JRadioButton();
        btnChatLieu = new javax.swing.JRadioButton();
        btnTenLoaiSP = new javax.swing.JRadioButton();
        btnThemTT = new javax.swing.JButton();
        btnSuaTT = new javax.swing.JButton();
        btnXoaTT = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblThuocTinhSP = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();

        setMinimumSize(new java.awt.Dimension(800, 800));
        setPreferredSize(new java.awt.Dimension(600, 800));

        tabs.setMinimumSize(new java.awt.Dimension(800, 800));

        jPanel1.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel5.setText("Mã sản phẩm");

        jLabel6.setText("Tên sản phẩm");

        jLabel8.setText("Giá bán");

        jLabel9.setText("Số lượng");

        jLabel11.setText("Size");

        jLabel12.setText("Chất liệu");

        cboKichThuoc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboChatLieu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel10.setText("Mô tả");

        jLabel7.setText("Trạng thái");

        buttonGroup2.add(rdoCon);
        rdoCon.setText("Còn hàng");

        buttonGroup2.add(rdoHet);
        rdoHet.setText("Hết hàng");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtSoLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMota, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtMaSP, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtTenSP, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtDonGia, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(39, 39, 39)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboKichThuoc, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 231, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(rdoHet)
                                    .addComponent(rdoCon))))))
                .addContainerGap(61, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtMaSP, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(16, 16, 16)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtTenSP, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(jPanel1Layout.createSequentialGroup()
                            .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(cboKichThuoc, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel11))
                            .addGap(44, 44, 44))
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cboChatLieu, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel12))))
                .addGap(16, 16, 16)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDonGia)
                        .addComponent(jLabel7)
                        .addComponent(rdoCon))
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtSoLuong)
                        .addComponent(rdoHet))
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(txtMota)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(17, Short.MAX_VALUE))
        );

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel4.setText("Quản lý sản phẩm");

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setText("Thông tin sản phẩm");

        jPanel2.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tblThongTinCT.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "ID SPCT", "Mã sản phẩm", "Tên sản phẩm", "Giá bán", "Số lượng", "Kích thước", "Chất liệu", "Trạng thái", "Mô tả", ""
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblThongTinCT.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblThongTinCTMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tblThongTinCT);

        btnSearch.setText("Tìm kiếm sản phẩm");
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 135, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 271, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTimKiem, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSearch))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 306, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        btnThemCT.setText("Thêm");
        btnThemCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnThemCTActionPerformed(evt);
            }
        });

        btnSuaCT.setText("Sửa");
        btnSuaCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuaCTActionPerformed(evt);
            }
        });

        btnMoiCT.setText("Mới");
        btnMoiCT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMoiCTActionPerformed(evt);
            }
        });

        btnAn.setText("Ẩn");
        btnAn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnActionPerformed(evt);
            }
        });

        jCheckBox1.setText("Hiển thị các sản phẩm đã ẩn");

        javax.swing.GroupLayout ThongTinLayout = new javax.swing.GroupLayout(ThongTin);
        ThongTin.setLayout(ThongTinLayout);
        ThongTinLayout.setHorizontalGroup(
            ThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThongTinLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(ThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(ThongTinLayout.createSequentialGroup()
                        .addComponent(btnThemCT)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnSuaCT)
                        .addGap(18, 18, 18)
                        .addComponent(btnMoiCT)
                        .addGap(18, 18, 18)
                        .addComponent(btnAn)
                        .addGap(173, 173, 173)
                        .addComponent(jCheckBox1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        ThongTinLayout.setVerticalGroup(
            ThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThongTinLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel13)
                .addGap(12, 12, 12)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addGroup(ThongTinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThemCT)
                    .addComponent(btnSuaCT)
                    .addComponent(btnMoiCT)
                    .addComponent(btnAn)
                    .addComponent(jCheckBox1))
                .addGap(20, 20, 20))
        );

        tabs.addTab("Thông tin chi tiết", ThongTin);

        jPanel3.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel2.setText("Tên thuộc tính");

        buttonGroup1.add(btnKichThuoc);
        btnKichThuoc.setText("Kích thước");

        buttonGroup1.add(btnChatLieu);
        btnChatLieu.setText("Chất liệu");

        buttonGroup1.add(btnTenLoaiSP);
        btnTenLoaiSP.setText("Tên loại sản phẩm");

        btnThemTT.setText("Thêm");

        btnSuaTT.setText("Sửa");

        btnXoaTT.setText("Xoá");

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(btnThemTT)
                        .addGap(18, 18, 18)
                        .addComponent(btnSuaTT)
                        .addGap(18, 18, 18)
                        .addComponent(btnXoaTT))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(txtTenThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, 260, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(84, 84, 84)
                        .addComponent(btnKichThuoc)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnChatLieu)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnTenLoaiSP)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTenThuocTinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnKichThuoc)
                    .addComponent(btnChatLieu)
                    .addComponent(btnTenLoaiSP))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 26, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThemTT)
                    .addComponent(btnSuaTT)
                    .addComponent(btnXoaTT))
                .addGap(22, 22, 22))
        );

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel1.setText("Thuộc tính sản phẩm");

        jPanel4.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        tblThuocTinhSP.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "STT", "Loại thuộc tính", "Tên thuộc tính"
            }
        ));
        jScrollPane1.setViewportView(tblThuocTinhSP);

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 723, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 488, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setText("Thông tin thuộc tính");

        javax.swing.GroupLayout ThuocTinhLayout = new javax.swing.GroupLayout(ThuocTinh);
        ThuocTinh.setLayout(ThuocTinhLayout);
        ThuocTinhLayout.setHorizontalGroup(
            ThuocTinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThuocTinhLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(ThuocTinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(ThuocTinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(22, Short.MAX_VALUE))
        );
        ThuocTinhLayout.setVerticalGroup(
            ThuocTinhLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ThuocTinhLayout.createSequentialGroup()
                .addGap(9, 9, 9)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addGap(14, 14, 14)
                .addComponent(jPanel4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        tabs.addTab("Thuộc tính sản phẩm", ThuocTinh);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(tabs, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

    public void setForm(int indexRow){
        SanPhamChiTiet spct = lst.get(indexRow);
        txtMaSP.setText(spct.getMaSPCT());
        txtTenSP.setText(spct.getTenSP());
        txtDonGia.setText(String.valueOf(spct.getGiaBan()));
        txtSoLuong.setText(String.valueOf(spct.getSoLuong()));
        txtMota.setText(spct.getMoTa());
        
        rdoCon.setSelected(spct.getTrangThai()==1);
        rdoHet.setSelected(spct.getTrangThai()==0);
        
        // Set combobox kích thước
        switch (spct.getKichThuocID()) {
            case 1:
                cboKichThuoc.setSelectedItem("S");
                break;
            case 2:
                cboKichThuoc.setSelectedItem("M");
                break;
            case 3:
                cboKichThuoc.setSelectedItem("L");
                break;
            default:
                cboKichThuoc.setSelectedItem("S");
                break;
        }
        
        // Set combobox chất liệu
        switch (spct.getChatLieuID()) {
            case 1:
                cboChatLieu.setSelectedItem("Chocolate");
                break;
            case 2:
                cboChatLieu.setSelectedItem("Trân Châu Đường Đen");
                break;
            case 3:
                cboChatLieu.setSelectedItem("Sữa kem");
                break;
            case 4:
                cboChatLieu.setSelectedItem("Hồng trà");
                break;
            default:
                cboChatLieu.setSelectedItem("Chocolate");
                break;
        }
    }
    
    // Phương thức kiểm tra validation riêng biệt
    public boolean validateForm() {
        if (txtMaSP.getText().trim().isEmpty() || 
            txtTenSP.getText().trim().isEmpty() || 
            txtDonGia.getText().trim().isEmpty() || 
            txtSoLuong.getText().trim().isEmpty()) {
            javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng nhập đầy đủ thông tin bắt buộc!");
            return false;
        }
        return true;
    }
    
    // Sửa lại getForm để trả về đối tượng SanPhamChiTiet (không validation)
    public SanPhamChiTiet getForm() {
        try {
            // Không kiểm tra validation ở đây để cho phép chỉnh sửa tự do
            
            SanPhamChiTiet spct = new SanPhamChiTiet();
            // Không set SanPhamChiTietID khi thêm mới (để tự động tăng)
            spct.setMaSPCT(txtMaSP.getText().trim());
            spct.setTenSP(txtTenSP.getText().trim());
            
            // Xử lý giá bán - nếu rỗng thì để 0
            String giaBanStr = txtDonGia.getText().trim();
            if (!giaBanStr.isEmpty()) {
                spct.setGiaBan(Double.parseDouble(giaBanStr));
            } else {
                spct.setGiaBan(0.0);
            }
            
            // Xử lý số lượng - nếu rỗng thì để 0
            String soLuongStr = txtSoLuong.getText().trim();
            if (!soLuongStr.isEmpty()) {
                spct.setSoLuong(Integer.parseInt(soLuongStr));
            } else {
                spct.setSoLuong(0);
            }
            
            // Lấy giá trị String từ ComboBox
            Object kichThuocObj = cboKichThuoc.getSelectedItem();
            Object chatLieuObj = cboChatLieu.getSelectedItem();
            
            if (kichThuocObj != null && kichThuocObj instanceof String) {
                // Chuyển đổi tên kích thước thành ID
                String kichThuocStr = (String) kichThuocObj;
                switch (kichThuocStr) {
                    case "S":
                        spct.setKichThuocID(1);
                        break;
                    case "M":
                        spct.setKichThuocID(2);
                        break;
                    case "L":
                        spct.setKichThuocID(3);
                        break;
                    default:
                        spct.setKichThuocID(1); // Mặc định S
                        break;
                }
            } else {
                spct.setKichThuocID(1); // Giá trị mặc định
            }
            
            if (chatLieuObj != null && chatLieuObj instanceof String) {
                // Chuyển đổi tên chất liệu thành ID
                String chatLieuStr = (String) chatLieuObj;
                switch (chatLieuStr) {
                    case "Chocolate":
                        spct.setChatLieuID(1);
                        break;
                    case "Trân Châu Đường Đen":
                        spct.setChatLieuID(2);
                        break;
                    case "Sữa kem":
                        spct.setChatLieuID(3);
                        break;
                    case "Hồng trà":
                        spct.setChatLieuID(4);
                        break;
                    default:
                        spct.setChatLieuID(1); // Mặc định Chocolate
                        break;
                }
            } else {
                spct.setChatLieuID(1); // Giá trị mặc định
            }
            
            spct.setTrangThai(rdoCon.isSelected() ? 1 : 0);
            spct.setMoTa(txtMota.getText().trim());
            
            // Set giá trị mặc định cho các trường khác
            spct.setSanPhamID(1); // Giá trị mặc định
            spct.setNgayTao(new java.util.Date());
            spct.setNgaySua(new java.util.Date());
            
            return spct;
        } catch (NumberFormatException e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Dữ liệu số không hợp lệ! Vui lòng kiểm tra lại.");
            return null;
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ: " + e.getMessage());
            return null;
        }
    }
    private void btnSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSearchActionPerformed
        // TODO add your handling code here:
        this.timKiem(evt);
        
    }//GEN-LAST:event_btnSearchActionPerformed

    private void tblThongTinCTMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblThongTinCTMouseClicked
        int index = tblThongTinCT.getSelectedRow();
        if (index >= 0 && index < lst.size()) {
            SanPhamChiTiet selectedSP = lst.get(index);
            
            // Kiểm tra nếu sản phẩm đã ẩn (trạng thái = 0) và đang hiển thị sản phẩm đã ẩn
            if (jCheckBox1.isSelected() && selectedSP.getTrangThai() == 0) {
                int confirm = javax.swing.JOptionPane.showConfirmDialog(this, 
                    "Sản phẩm '" + selectedSP.getTenSP() + "' đã bị ẩn.\nBạn có muốn hiển thị lại sản phẩm này không?", 
                    "Hiển thị lại sản phẩm", 
                    javax.swing.JOptionPane.YES_NO_OPTION);
                    
                if (confirm == javax.swing.JOptionPane.YES_OPTION) {
                    // Cập nhật trạng thái từ ẩn (0) thành hiển thị (1)
                    selectedSP.setTrangThai(1);
                    if (spctRepo.update(selectedSP.getSanPhamChiTietID(), selectedSP)) {
                        javax.swing.JOptionPane.showMessageDialog(this, "Đã hiển thị lại sản phẩm thành công!");
                        // Refresh bảng theo trạng thái checkbox
                        if (jCheckBox1.isSelected()) {
                            fillTableSP(spctRepo.getAll());
                        } else {
                            fillTableSP(spctRepo.getAllActive());
                        }
                    } else {
                        javax.swing.JOptionPane.showMessageDialog(this, "Hiển thị lại sản phẩm thất bại!");
                    }
                }
            } else {
                // Nếu sản phẩm còn hàng hoặc không phải đang xem sản phẩm đã ẩn thì set form bình thường
                this.setForm(index);
            }
        }
    }//GEN-LAST:event_tblThongTinCTMouseClicked

    private void btnMoiCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMoiCTActionPerformed
        txtMaSP.setText("");
        txtTenSP.setText("");
        txtDonGia.setText("");
        txtSoLuong.setText("");
        txtMota.setText("");
        rdoCon.setSelected(true);
        cboKichThuoc.setSelectedIndex(0);
        cboChatLieu.setSelectedIndex(0);
    }//GEN-LAST:event_btnMoiCTActionPerformed

    private void btnSuaCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuaCTActionPerformed
        int index = tblThongTinCT.getSelectedRow();
        if (index < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần sửa!");
            return;
        }
        
        // Lấy ID của sản phẩm cần sửa
        SanPhamChiTiet spctOld = lst.get(index);
        int id = spctOld.getSanPhamChiTietID();
        
        SanPhamChiTiet spct = getForm();
        if (spct == null) return;
        
        // Set lại ID cho sản phẩm cần sửa
        spct.setSanPhamChiTietID(id);
        
        if (spctRepo.update(id, spct)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Sửa sản phẩm thành công!");
            // Cập nhật bảng theo trạng thái checkbox
            if (jCheckBox1.isSelected()) {
                fillTableSP(spctRepo.getAll());
            } else {
                fillTableSP(spctRepo.getAllActive());
            }
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Sửa sản phẩm thất bại!");
        }
    }//GEN-LAST:event_btnSuaCTActionPerformed

    private void btnThemCTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnThemCTActionPerformed
        SanPhamChiTiet spct = getForm();
        if (spct == null) return;
        
        if (spctRepo.add(spct)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm sản phẩm thành công!");
            // Cập nhật bảng theo trạng thái checkbox
            if (jCheckBox1.isSelected()) {
                fillTableSP(spctRepo.getAll());
            } else {
                fillTableSP(spctRepo.getAllActive());
            }
            // Làm mới form sau khi thêm thành công
            btnMoiCTActionPerformed(evt);
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm sản phẩm thất bại!");
        }
    }//GEN-LAST:event_btnThemCTActionPerformed

    private void btnAnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnActionPerformed
        int index = tblThongTinCT.getSelectedRow();
        if (index < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần ẩn!");
            return;
        }
        
        // Lấy sản phẩm cần ẩn
        SanPhamChiTiet spct = lst.get(index);
        
        // Kiểm tra nếu sản phẩm đã bị ẩn rồi
        if (spct.getTrangThai() == 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Sản phẩm này đã bị ẩn rồi!");
            return;
        }
        
        // Xác nhận ẩn sản phẩm
        int confirm = javax.swing.JOptionPane.showConfirmDialog(this, 
            "Bạn có chắc chắn muốn ẩn sản phẩm '" + spct.getTenSP() + "'?", 
            "Xác nhận ẩn sản phẩm", 
            javax.swing.JOptionPane.YES_NO_OPTION);
            
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            // Cập nhật trạng thái từ hiển thị (1) thành ẩn (0)
            spct.setTrangThai(0);
            if (spctRepo.update(spct.getSanPhamChiTietID(), spct)) {
                javax.swing.JOptionPane.showMessageDialog(this, "Đã ẩn sản phẩm thành công!");
                // Cập nhật bảng theo trạng thái checkbox
                if (jCheckBox1.isSelected()) {
                    fillTableSP(spctRepo.getAll());
                } else {
                    fillTableSP(spctRepo.getAllActive());
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "Ẩn sản phẩm thất bại!");
            }
        }
    }//GEN-LAST:event_btnAnActionPerformed

    // Hàm xử lý sự kiện radiobutton Kích thước
    private void btnKichThuocActionPerformed(java.awt.event.ActionEvent evt) {
        loaiThuocTinhHienTai = "Kích thước";
        fillTableThuocTinh();
    }
    
    // Hàm xử lý sự kiện radiobutton Chất liệu
    private void btnChatLieuActionPerformed(java.awt.event.ActionEvent evt) {
        loaiThuocTinhHienTai = "Chất liệu";
        fillTableThuocTinh();
    }
    
    // Hàm xử lý sự kiện radiobutton Tên loại sản phẩm
    private void btnTenLoaiSPActionPerformed(java.awt.event.ActionEvent evt) {
        loaiThuocTinhHienTai = "Tên loại sản phẩm";
        fillTableThuocTinh();
    }
    
    // Hàm lấy dữ liệu từ form thuộc tính
    public ThuocTinh getFormThuocTinh() {
        try {
            if (txtTenThuocTinh.getText().trim().isEmpty()) {
                javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng nhập tên thuộc tính!");
                return null;
            }
            
            ThuocTinh tt = new ThuocTinh();
            tt.setTenThuocTinh(txtTenThuocTinh.getText().trim());
            tt.setLoaiThuocTinh(loaiThuocTinhHienTai);
            tt.setTrangThai(1);
            tt.setNgayTao(new java.util.Date());
            tt.setNgaySua(new java.util.Date());
            
            return tt;
        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(this, "Dữ liệu không hợp lệ: " + e.getMessage());
            return null;
        }
    }
    
    // Hàm xử lý sự kiện nút Thêm thuộc tính
    private void btnThemTTActionPerformed(java.awt.event.ActionEvent evt) {
        ThuocTinh tt = getFormThuocTinh();
        if (tt == null) return;
        
        if (ttRepo.add(tt)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm thuộc tính thành công!");
            fillTableThuocTinh();
            // Cập nhật combobox nếu cần
            if (loaiThuocTinhHienTai.equals("Kích thước")) {
                fillToComboboxKT();
            } else if (loaiThuocTinhHienTai.equals("Chất liệu")) {
                fillToComboboxCL();
            }
            txtTenThuocTinh.setText("");
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm thuộc tính thất bại!");
        }
    }
    
    // Hàm xử lý sự kiện nút Sửa thuộc tính
    private void btnSuaTTActionPerformed(java.awt.event.ActionEvent evt) {
        int index = tblThuocTinhSP.getSelectedRow();
        if (index < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng chọn thuộc tính cần sửa!");
            return;
        }
        
        ThuocTinh tt = getFormThuocTinh();
        if (tt == null) return;
        
        ThuocTinh ttOld = lstThuocTinh.get(index);
        tt.setThuocTinhID(ttOld.getThuocTinhID());
        
        if (ttRepo.update(ttOld.getThuocTinhID(), tt)) {
            javax.swing.JOptionPane.showMessageDialog(this, "Sửa thuộc tính thành công!");
            fillTableThuocTinh();
            // Cập nhật combobox nếu cần
            if (loaiThuocTinhHienTai.equals("Kích thước")) {
                fillToComboboxKT();
            } else if (loaiThuocTinhHienTai.equals("Chất liệu")) {
                fillToComboboxCL();
            }
            txtTenThuocTinh.setText("");
        } else {
            javax.swing.JOptionPane.showMessageDialog(this, "Sửa thuộc tính thất bại!");
        }
    }
    
    // Hàm xử lý sự kiện nút Ẩn thuộc tính
    private void btnXoaTTActionPerformed(java.awt.event.ActionEvent evt) {
        int index = tblThuocTinhSP.getSelectedRow();
        if (index < 0) {
            javax.swing.JOptionPane.showMessageDialog(this, "Vui lòng chọn thuộc tính cần ẩn!");
            return;
        }
        
        ThuocTinh tt = lstThuocTinh.get(index);
        
        int confirm = javax.swing.JOptionPane.showConfirmDialog(this, 
            "Bạn có chắc chắn muốn ẩn thuộc tính '" + tt.getTenThuocTinh() + "'?\n(Lưu ý: Thuộc tính đang được sử dụng sẽ không hiển thị trong combobox)", 
            "Xác nhận ẩn", 
            javax.swing.JOptionPane.YES_NO_OPTION);
            
        if (confirm == javax.swing.JOptionPane.YES_OPTION) {
            if (ttRepo.hide(tt.getThuocTinhID())) {
                javax.swing.JOptionPane.showMessageDialog(this, "Đã ẩn thuộc tính thành công!");
                fillTableThuocTinh();
                // Cập nhật combobox nếu cần
                if (loaiThuocTinhHienTai.equals("Kích thước")) {
                    fillToComboboxKT();
                } else if (loaiThuocTinhHienTai.equals("Chất liệu")) {
                    fillToComboboxCL();
                }
            } else {
                javax.swing.JOptionPane.showMessageDialog(this, "Ẩn thuộc tính thất bại!");
            }
        }
    }

    // Hàm xử lý sự kiện click vào bảng thuộc tính
    private void tblThuocTinhSPMouseClicked(java.awt.event.MouseEvent evt) {
        int index = tblThuocTinhSP.getSelectedRow();
        if (index >= 0 && index < lstThuocTinh.size()) {
            ThuocTinh tt = lstThuocTinh.get(index);
            txtTenThuocTinh.setText(tt.getTenThuocTinh());
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel ThongTin;
    private javax.swing.JPanel ThuocTinh;
    private javax.swing.JButton btnAn;
    private javax.swing.JRadioButton btnChatLieu;
    private javax.swing.JRadioButton btnKichThuoc;
    private javax.swing.JButton btnMoiCT;
    private javax.swing.JButton btnSearch;
    private javax.swing.JButton btnSuaCT;
    private javax.swing.JButton btnSuaTT;
    private javax.swing.JRadioButton btnTenLoaiSP;
    private javax.swing.JButton btnThemCT;
    private javax.swing.JButton btnThemTT;
    private javax.swing.JButton btnXoaTT;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.ButtonGroup buttonGroup2;
    private javax.swing.JComboBox<String> cboChatLieu;
    private javax.swing.JComboBox<String> cboKichThuoc;
    private javax.swing.JCheckBox jCheckBox1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JRadioButton rdoCon;
    private javax.swing.JRadioButton rdoHet;
    private javax.swing.JTabbedPane tabs;
    private javax.swing.JTable tblThongTinCT;
    private javax.swing.JTable tblThuocTinhSP;
    private javax.swing.JTextField txtDonGia;
    private javax.swing.JTextField txtMaSP;
    private javax.swing.JTextField txtMota;
    private javax.swing.JTextField txtSoLuong;
    private javax.swing.JTextField txtTenSP;
    private javax.swing.JTextField txtTenThuocTinh;
    private javax.swing.JTextField txtTimKiem;
    // End of variables declaration//GEN-END:variables
}
