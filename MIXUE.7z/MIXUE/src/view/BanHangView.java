/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package view;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import model.HoaDon;
import model.HoaDonChiTiet;
import model.SanPhamChiTiet;
import repository.SanPhamChiTietRepository;
import util.SessionManager;

/**
 *
 * @author ADMIN
 */
public class BanHangView extends javax.swing.JPanel {
    
    private SanPhamChiTietRepository spctRepo;
    private List<SanPhamChiTiet> danhSachSanPham;
    private List<HoaDonChiTiet> gioHang;
    private DefaultTableModel modelHoaDon;
    private DefaultTableModel modelSanPham;
    private DefaultTableModel modelGioHang;
    private DecimalFormat df = new DecimalFormat("#,###");
    private int soHoaDon = 1;

    /**
     * Creates new form BanHangView
     */
    public BanHangView() {
        initComponents();
        initializeData();
        setupTables();
        loadSanPham();
        taoHoaDonMoi();
    }
    
    private void initializeData() {
        spctRepo = new SanPhamChiTietRepository();
        danhSachSanPham = new ArrayList<>();
        gioHang = new ArrayList<>();
    }
    
    private void setupTables() {
        // Thiết lập bảng hóa đơn
        modelHoaDon = (DefaultTableModel) tblHoaDon.getModel();
        
        // Thiết lập bảng sản phẩm
        modelSanPham = (DefaultTableModel) tblSanPham.getModel();
        
        // Thiết lập bảng giỏ hàng
        modelGioHang = (DefaultTableModel) tblGioHang.getModel();
    }
    
    private void loadSanPham() {
        try {
            danhSachSanPham = spctRepo.getAllActive();
            modelSanPham.setRowCount(0);
            
            for (SanPhamChiTiet sp : danhSachSanPham) {
                modelSanPham.addRow(new Object[]{
                    sp.getMaSPCT(),
                    sp.getTenSP(),
                    sp.getSoLuong(),
                    df.format(sp.getGiaBan()) + " VNĐ",
                    sp.getKichThuocID(),
                    sp.getChatLieuID(),
                    sp.getTrangThai() == 1 ? "Còn hàng" : "Hết hàng"
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Lỗi khi tải danh sách sản phẩm: " + e.getMessage());
        }
    }
    
    private void taoHoaDonMoi() {
        // Tạo mã hóa đơn mới
        String maHD = "HD" + String.format("%04d", soHoaDon++);
        txtMaHoaDon.setText(maHD);
        
        // Reset thông tin khách hàng
        txtTenKhach.setText("");
        txtSoDienThoai.setText("");
        txtDiaChi.setText("");
        
        // Reset giỏ hàng
        gioHang.clear();
        modelGioHang.setRowCount(0);
        
        // Reset tính tiền
        txtTongTien.setText("0");
        txtTienShip.setText("0");
        txtKhachCanTra.setText("0");
        txtTienThua.setText("0");
        
        // Set ngày hiện tại
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        // Giả sử có label hiển thị ngày tạo
    }
    
    private void themVaoGioHang() {
        int selectedRow = tblSanPham.getSelectedRow();
        if (selectedRow < 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn sản phẩm cần thêm!");
            return;
        }
        
        try {
            SanPhamChiTiet sp = danhSachSanPham.get(selectedRow);
            
            // Kiểm tra số lượng
            if (sp.getSoLuong() <= 0) {
                JOptionPane.showMessageDialog(this, "Sản phẩm đã hết hàng!");
                return;
            }
            
            // Nhập số lượng
            String soLuongStr = JOptionPane.showInputDialog(this, "Nhập số lượng:", "1");
            if (soLuongStr == null || soLuongStr.trim().isEmpty()) {
                return;
            }
            
            int soLuong = Integer.parseInt(soLuongStr);
            if (soLuong <= 0 || soLuong > sp.getSoLuong()) {
                JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ!");
                return;
            }
            
            // Kiểm tra sản phẩm đã có trong giỏ hàng chưa
            boolean found = false;
            for (HoaDonChiTiet item : gioHang) {
                if (item.getSanPhamChiTietID() == sp.getSanPhamChiTietID()) {
                    item.setSoLuong(item.getSoLuong() + soLuong);
                    item.calculateThanhTien();
                    found = true;
                    break;
                }
            }
            
            if (!found) {
                HoaDonChiTiet hdct = new HoaDonChiTiet();
                hdct.setSanPhamChiTietID(sp.getSanPhamChiTietID());
                hdct.setTenSanPham(sp.getTenSP());
                hdct.setSoLuong(soLuong);
                hdct.setDonGia(sp.getGiaBan());
                hdct.calculateThanhTien();
                gioHang.add(hdct);
            }
            
            capNhatGioHang();
            tinhTongTien();
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Số lượng phải là số nguyên!");
        }
    }
    
    private void capNhatGioHang() {
        modelGioHang.setRowCount(0);
        for (HoaDonChiTiet item : gioHang) {
            modelGioHang.addRow(new Object[]{
                item.getTenSanPham(),
                item.getSoLuong(),
                df.format(item.getDonGia()) + " VNĐ",
                df.format(item.getThanhTien()) + " VNĐ"
            });
        }
    }
    
    private void tinhTongTien() {
        double tongTien = 0;
        for (HoaDonChiTiet item : gioHang) {
            tongTien += item.getThanhTien();
        }
        
        double tienShip = 0;
        try {
            tienShip = Double.parseDouble(txtTienShip.getText().replaceAll("[^0-9.]", ""));
        } catch (Exception e) {
            tienShip = 0;
        }
        
        double khachCanTra = tongTien + tienShip;
        
        txtTongTien.setText(df.format(tongTien));
        txtKhachCanTra.setText(df.format(khachCanTra));
        
        // Tính tiền thừa
        tinhTienThua();
    }
    
    private void tinhTienThua() {
        try {
            double khachCanTra = Double.parseDouble(txtKhachCanTra.getText().replaceAll("[^0-9.]", ""));
            double tienKhachDua = Double.parseDouble(txtTienKhachDua.getText().replaceAll("[^0-9.]", ""));
            double tienThua = tienKhachDua - khachCanTra;
            
            txtTienThua.setText(df.format(Math.max(0, tienThua)));
        } catch (Exception e) {
            txtTienThua.setText("0");
        }
    }
    
    // Event handlers
    private void btnThemActionPerformed(java.awt.event.ActionEvent evt) {
        themVaoGioHang();
    }
    
    private void txtTienShipKeyReleased(java.awt.event.KeyEvent evt) {
        tinhTongTien();
    }
    
    private void txtTienKhachDuaKeyReleased(java.awt.event.KeyEvent evt) {
        tinhTienThua();
    }
    
    private void btnTaoHoaDonActionPerformed(java.awt.event.ActionEvent evt) {
        taoHoaDonMoi();
    }
    
    // Simplified initComponents method
    @SuppressWarnings("unchecked")
    private void initComponents() {
        // Initialize all GUI components
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblHoaDon = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblSanPham = new javax.swing.JTable();
        btnThem = new javax.swing.JButton();
        jPanel3 = new javax.swing.JPanel();
        txtMaHoaDon = new javax.swing.JTextField();
        txtTenKhach = new javax.swing.JTextField();
        txtSoDienThoai = new javax.swing.JTextField();
        txtDiaChi = new javax.swing.JTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblGioHang = new javax.swing.JTable();
        txtTongTien = new javax.swing.JTextField();
        txtTienShip = new javax.swing.JTextField();
        txtKhachCanTra = new javax.swing.JTextField();
        txtTienKhachDua = new javax.swing.JTextField();
        txtTienThua = new javax.swing.JTextField();
        cboHinhThucThanhToan = new javax.swing.JComboBox<>();
        btnTaoHoaDon = new javax.swing.JButton();
        btnDatGiao = new javax.swing.JButton();
        btnHoaTa = new javax.swing.JButton();
        btnXoa = new javax.swing.JButton();
        
        setMinimumSize(new java.awt.Dimension(1200, 800));
        setPreferredSize(new java.awt.Dimension(1200, 800));
        
        // Setup tables
        setupTableModels();
        setupLayout();
        setupEventHandlers();
    }
    
    private void setupTableModels() {
        // Hóa đơn table
        tblHoaDon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"STT", "Mã HD", "Tên KH", "Tình trạng", "Ngày tạo"}
        ));
        
        // Sản phẩm table
        tblSanPham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"Mã SP", "Tên sản phẩm", "Số lượng", "Giá bán", "Kích thước", "Chất liệu", "Trạng thái"}
        ));
        
        // Giỏ hàng table
        tblGioHang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {},
            new String [] {"Tên sản phẩm", "Số lượng", "Đơn giá", "Thành tiền"}
        ));
    }
    
    private void setupLayout() {
        // Basic layout setup - simplified version
        setLayout(new java.awt.BorderLayout());
        
        // Left panel - Invoice list
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách hóa đơn"));
        jScrollPane1.setViewportView(tblHoaDon);
        jPanel1.add(jScrollPane1);
        
        // Center panel - Product list
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách sản phẩm"));
        jScrollPane2.setViewportView(tblSanPham);
        jPanel2.add(jScrollPane2);
        jPanel2.add(btnThem);
        
        // Right panel - Invoice creation
        jPanel3.setBorder(javax.swing.BorderFactory.createTitledBorder("Tạo hóa đơn"));
        jScrollPane3.setViewportView(tblGioHang);
        
        // Add panels to main layout
        add(jPanel1, java.awt.BorderLayout.WEST);
        add(jPanel2, java.awt.BorderLayout.CENTER);
        add(jPanel3, java.awt.BorderLayout.EAST);
    }
    
    private void setupEventHandlers() {
        btnThem.addActionListener(evt -> themVaoGioHang());
        btnTaoHoaDon.addActionListener(evt -> taoHoaDonMoi());
        txtTienShip.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tinhTongTien();
            }
        });
        txtTienKhachDua.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tinhTienThua();
            }
        });
    }
    
    // Variables declaration
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTable tblHoaDon;
    private javax.swing.JTable tblSanPham;
    private javax.swing.JTable tblGioHang;
    private javax.swing.JTextField txtMaHoaDon;
    private javax.swing.JTextField txtTenKhach;
    private javax.swing.JTextField txtSoDienThoai;
    private javax.swing.JTextField txtDiaChi;
    private javax.swing.JTextField txtTongTien;
    private javax.swing.JTextField txtTienShip;
    private javax.swing.JTextField txtKhachCanTra;
    private javax.swing.JTextField txtTienKhachDua;
    private javax.swing.JTextField txtTienThua;
    private javax.swing.JComboBox<String> cboHinhThucThanhToan;
    private javax.swing.JButton btnThem;
    private javax.swing.JButton btnTaoHoaDon;
    private javax.swing.JButton btnDatGiao;
    private javax.swing.JButton btnHoaTa;
    private javax.swing.JButton btnXoa;
}
