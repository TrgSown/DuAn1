/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.*;
import util.ConnectDB;
import model.NhanVien;

/**
 *
 * @author ADMIN
 */
public class NhanVienRepository {
    private Connection cn = null;
    public NhanVienRepository(){
         cn = ConnectDB.getConnect();
    }
    
   // Phương thức đăng nhập cũ (giữ lại để tương thích)
   public boolean login(String ma, String matkhau){
       Boolean result = null;
       String sql = """
                    SELECT * FROM NhanVien
                    WHERE MaNV = ? AND MatKhau = ? AND TrangThai = 1;
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ps.setString(1, ma);
           ps.setString(2, matkhau);
           ResultSet rs = ps.executeQuery();
           result = rs.next() ? true : false;
       }catch (Exception e){
           e.printStackTrace();
       }
       return result;
   }
   
   // Phương thức đăng nhập mới với thông tin người dùng và quyền
   public NhanVien loginWithRole(String ma, String matkhau){
       NhanVien nhanVien = null;
       // Thử truy vấn với cột ChucVu trước
       String sqlWithRole = """
                    SELECT NhanVienID, MaNV, TenNV, MatKhau, ChucVu, TrangThai 
                    FROM NhanVien
                    WHERE MaNV = ? AND MatKhau = ? AND TrangThai = 1;
                    """;
       
       // Nếu không có cột ChucVu, sử dụng truy vấn cơ bản
       String sqlBasic = """
                    SELECT * FROM NhanVien
                    WHERE MaNV = ? AND MatKhau = ? AND TrangThai = 1;
                    """;
       
       try{
           PreparedStatement ps = cn.prepareStatement(sqlWithRole);
           ps.setString(1, ma);
           ps.setString(2, matkhau);
           ResultSet rs = ps.executeQuery();
           
           if (rs.next()) {
               nhanVien = new NhanVien();
               nhanVien.setNhanVienID(rs.getInt("NhanVienID"));
               nhanVien.setMaNV(rs.getString("MaNV"));
               nhanVien.setTenNV(rs.getString("TenNV"));
               nhanVien.setMatKhau(rs.getString("MatKhau"));
               nhanVien.setChucVu(rs.getString("ChucVu"));
               nhanVien.setTrangThai(rs.getInt("TrangThai"));
           }
       } catch (Exception e) {
           // Nếu lỗi do không có cột ChucVu, thử truy vấn cơ bản
           try {
               PreparedStatement ps = cn.prepareStatement(sqlBasic);
               ps.setString(1, ma);
               ps.setString(2, matkhau);
               ResultSet rs = ps.executeQuery();
               
               if (rs.next()) {
                   nhanVien = new NhanVien();
                   // Gán giá trị từ các cột có sẵn
                   if (hasColumn(rs, "NhanVienID")) {
                       nhanVien.setNhanVienID(rs.getInt("NhanVienID"));
                   }
                   nhanVien.setMaNV(rs.getString("MaNV"));
                   if (hasColumn(rs, "TenNV")) {
                       nhanVien.setTenNV(rs.getString("TenNV"));
                   } else {
                       nhanVien.setTenNV("User"); // Giá trị mặc định
                   }
                   nhanVien.setMatKhau(rs.getString("MatKhau"));
                   
                   // Gán quyền dựa trên mã nhân viên hoặc logic khác
                   if (ma.toLowerCase().contains("admin") || ma.toLowerCase().startsWith("ad")) {
                       nhanVien.setChucVu("Admin");
                   } else {
                       nhanVien.setChucVu("NhanVien");
                   }
                   
                   if (hasColumn(rs, "TrangThai")) {
                       nhanVien.setTrangThai(rs.getInt("TrangThai"));
                   } else {
                       nhanVien.setTrangThai(1); // Mặc định là hoạt động
                   }
               }
           } catch (Exception ex) {
               ex.printStackTrace();
           }
       }
       return nhanVien;
   }
   
   // Phương thức kiểm tra cột có tồn tại hay không
   private boolean hasColumn(ResultSet rs, String columnName) {
       try {
           rs.findColumn(columnName);
           return true;
       } catch (Exception e) {
           return false;
       }
   }
   
   
}
