package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.ThuocTinh;
import util.ConnectDB;

/**
 *
 * @author ADMIN
 */
public class ThuocTinhRepository {
    private java.sql.Connection cn = null;
    
    public ThuocTinhRepository(){
         cn = ConnectDB.getConnect();
    }
    
    public ArrayList<ThuocTinh> getAll(){
       ArrayList<ThuocTinh> lst = new ArrayList<>();
       String sql = """
                   SELECT [ThuocTinhID]
                            ,[TenThuocTinh]
                            ,[LoaiThuocTinh]
                            ,[TrangThai]
                            ,[NgayTao]
                            ,[NgaySua]
                        FROM [dbo].[ThuocTinh]
                        ORDER BY [LoaiThuocTinh], [TenThuocTinh]
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ResultSet rs = ps.executeQuery();
           while (rs.next()) {               
               lst.add(new ThuocTinh(
                       rs.getInt("ThuocTinhID"),
                       rs.getString("TenThuocTinh"),
                       rs.getString("LoaiThuocTinh"),
                       rs.getInt("TrangThai"),
                       rs.getDate("NgayTao"),
                       rs.getDate("NgaySua")
               ));
        }
       }catch (Exception e){
           e.printStackTrace();
       }
       return lst;
   }
    
    // Lấy thuộc tính theo loại
    public ArrayList<ThuocTinh> getByLoai(String loaiThuocTinh){
       ArrayList<ThuocTinh> lst = new ArrayList<>();
       String sql = """
                   SELECT [ThuocTinhID]
                            ,[TenThuocTinh]
                            ,[LoaiThuocTinh]
                            ,[TrangThai]
                            ,[NgayTao]
                            ,[NgaySua]
                        FROM [dbo].[ThuocTinh]
                        WHERE [LoaiThuocTinh] = ? AND [TrangThai] = 1
                        ORDER BY [TenThuocTinh]
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ps.setString(1, loaiThuocTinh);
           ResultSet rs = ps.executeQuery();
           while (rs.next()) {               
               lst.add(new ThuocTinh(
                       rs.getInt("ThuocTinhID"),
                       rs.getString("TenThuocTinh"),
                       rs.getString("LoaiThuocTinh"),
                       rs.getInt("TrangThai"),
                       rs.getDate("NgayTao"),
                       rs.getDate("NgaySua")
               ));
        }
       }catch (Exception e){
           e.printStackTrace();
       }
       return lst;
   }
    
    // Thêm thuộc tính mới
    public boolean add(ThuocTinh tt) {
        String sql = "INSERT INTO ThuocTinh (TenThuocTinh, LoaiThuocTinh, TrangThai, NgayTao, NgaySua) VALUES (?, ?, ?, GETDATE(), GETDATE())";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, tt.getTenThuocTinh());
            ps.setString(2, tt.getLoaiThuocTinh());
            ps.setInt(3, tt.getTrangThai());
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Sửa thuộc tính
    public boolean update(int id, ThuocTinh tt) {
        String sql = "UPDATE ThuocTinh SET TenThuocTinh=?, LoaiThuocTinh=?, TrangThai=?, NgaySua=GETDATE() WHERE ThuocTinhID=?";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, tt.getTenThuocTinh());
            ps.setString(2, tt.getLoaiThuocTinh());
            ps.setInt(3, tt.getTrangThai());
            ps.setInt(4, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Ẩn thuộc tính thay vì xoá (để tránh lỗi foreign key)
    public boolean hide(int id) {
        String sql = "UPDATE ThuocTinh SET TrangThai=0, NgaySua=GETDATE() WHERE ThuocTinhID=?";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
} 