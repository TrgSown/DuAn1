/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.SanPham;
import util.ConnectDB;

/**
 *
 * @author ADMIN
 */
public class SanPhamRepository {
private java.sql.Connection cn = null;
    public SanPhamRepository(){
         cn = ConnectDB.getConnect();
    }
    
   public ArrayList<SanPham> getAll(){
       ArrayList<SanPham> lst = new ArrayList<>();
       String sql = """
                    SELECT [SanPhamID]
                          ,[MaSP]
                          ,[TenSP]
                          ,[NgayTao]
                          ,[NgaySua]
                      FROM [dbo].[SanPham]
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ResultSet rs = ps.executeQuery();
           while (rs.next()) {               
               lst.add(new SanPham(
                       rs.getInt("SanPhamID"),
                       rs.getString("MaSP"),
                       rs.getString("TenSP"),
                       rs.getDate("NgayTao"),
                       rs.getDate("NgaySua")
               ));
        }
       }catch (Exception e){
           e.printStackTrace();
       }
       return lst;
   }       
}
