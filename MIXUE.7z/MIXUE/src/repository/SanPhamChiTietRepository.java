/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package repository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.SanPham;
import model.SanPhamChiTiet;
import util.ConnectDB;

/**
 *
 * @author ADMIN
 */
public class SanPhamChiTietRepository {
    private java.sql.Connection cn = null;
    public SanPhamChiTietRepository(){
         cn = ConnectDB.getConnect();
    }
    
   public ArrayList<SanPhamChiTiet> getAll(){
       ArrayList<SanPhamChiTiet> lst = new ArrayList<>();
       String sql = """
                   SELECT [SanPhamChiTietID]
                            ,[MaSPCT]
                            ,[TenSP]
                            ,[SoLuong]
                            ,[GiaBan]
                            ,[TrangThai]
                            ,[MoTa]
                            ,[NgayTao]
                            ,[NgayChinhSua]
                            ,[SanPhamID]
                            ,[ThuocTinhChatLieuID]
                            ,[ThuocTinhKichThuocID]
                        FROM [dbo].[SanPhamChiTiet]
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ResultSet rs = ps.executeQuery();
           while (rs.next()) {               
               lst.add(new SanPhamChiTiet(
                       rs.getInt("SanPhamChiTietID"),
                       rs.getString("MaSPCT"),
                       rs.getString("TenSP"),
                       rs.getInt("SoLuong"),
                       rs.getDouble("GiaBan"),
                       rs.getInt("TrangThai"),
                       rs.getString("Mota"),
                       rs.getDate("NgayTao"),
                       rs.getDate("NgayChinhSua"),
                       rs.getInt("SanPhamID"),
                       rs.getInt("ThuocTinhChatLieuID"),
                       rs.getInt("ThuocTinhKichThuocID")
               ));
        }
       }catch (Exception e){
           e.printStackTrace();
       }
       return lst;
   }       

    // Thêm sản phẩm chi tiết mới
    public boolean add(SanPhamChiTiet spct) {
        String sql = "INSERT INTO SanPhamChiTiet (MaSPCT, TenSP, SoLuong, GiaBan, TrangThai, MoTa, NgayTao, NgayChinhSua, SanPhamID, ThuocTinhKichThuocID, ThuocTinhChatLieuID) VALUES (?, ?, ?, ?, ?, ?, GETDATE(), GETDATE(), ?, ?, ?)";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, spct.getMaSPCT());
            ps.setString(2, spct.getTenSP());
            ps.setInt(3, spct.getSoLuong());
            ps.setDouble(4, spct.getGiaBan());
            ps.setInt(5, spct.getTrangThai());
            ps.setString(6, spct.getMoTa());
            ps.setInt(7, spct.getSanPhamID());
            ps.setInt(8, spct.getKichThuocID()); // Lưu ThuocTinhID thay vì KichThuocID
            ps.setInt(9, spct.getChatLieuID()); // Lưu ThuocTinhID thay vì ChatLieuID
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Sửa sản phẩm chi tiết theo ID
    public boolean update(int id, SanPhamChiTiet spct) {
        String sql = "UPDATE SanPhamChiTiet SET MaSPCT=?, TenSP=?, SoLuong=?, GiaBan=?, TrangThai=?, MoTa=?, NgayChinhSua=GETDATE(), SanPhamID=?, ThuocTinhKichThuocID=?, ThuocTinhChatLieuID=? WHERE SanPhamChiTietID=?";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setString(1, spct.getMaSPCT());
            ps.setString(2, spct.getTenSP());
            ps.setInt(3, spct.getSoLuong());
            ps.setDouble(4, spct.getGiaBan());
            ps.setInt(5, spct.getTrangThai());
            ps.setString(6, spct.getMoTa());
            ps.setInt(7, spct.getSanPhamID());
            ps.setInt(8, spct.getKichThuocID()); // Lưu ThuocTinhID thay vì KichThuocID
            ps.setInt(9, spct.getChatLieuID()); // Lưu ThuocTinhID thay vì ChatLieuID
            ps.setInt(10, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Xoá sản phẩm chi tiết theo ID
    public boolean remove(int id) {
        String sql = "DELETE FROM SanPhamChiTiet WHERE SanPhamChiTietID=?";
        try {
            PreparedStatement ps = cn.prepareStatement(sql);
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Lấy tất cả sản phẩm còn hàng (trạng thái = 1)
    public ArrayList<SanPhamChiTiet> getAllActive(){
       ArrayList<SanPhamChiTiet> lst = new ArrayList<>();
       String sql = """
                   SELECT [SanPhamChiTietID]
                            ,[MaSPCT]
                            ,[TenSP]
                            ,[SoLuong]
                            ,[GiaBan]
                            ,[TrangThai]
                            ,[MoTa]
                            ,[NgayTao]
                            ,[NgayChinhSua]
                            ,[SanPhamID]
                            ,[ThuocTinhChatLieuID]
                            ,[ThuocTinhKichThuocID]
                        FROM [dbo].[SanPhamChiTiet]
                        WHERE [TrangThai] = 1
                    """;
       try{
           PreparedStatement ps = cn.prepareStatement(sql);
           ResultSet rs = ps.executeQuery();
           while (rs.next()) {               
               lst.add(new SanPhamChiTiet(
                       rs.getInt("SanPhamChiTietID"),
                       rs.getString("MaSPCT"),
                       rs.getString("TenSP"),
                       rs.getInt("SoLuong"),
                       rs.getDouble("GiaBan"),
                       rs.getInt("TrangThai"),
                       rs.getString("Mota"),
                       rs.getDate("NgayTao"),
                       rs.getDate("NgayChinhSua"),
                       rs.getInt("SanPhamID"),
                       rs.getInt("ThuocTinhChatLieuID"),
                       rs.getInt("ThuocTinhKichThuocID")
               ));
        }
       }catch (Exception e){
           e.printStackTrace();
       }
       return lst;
   }
}
