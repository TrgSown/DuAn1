/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */

public class SanPham {
    private int sanPhamID;
    private String maSP;
    private String tenSP;
    private Date ngayTao;
    private Date ngaySua;

    public SanPham(int sanPhamID, String maSP, String tenSP, Date ngayTao, Date ngaySua) {
        this.sanPhamID = sanPhamID;
        this.maSP = maSP;
        this.tenSP = tenSP;
        this.ngayTao = ngayTao;
        this.ngaySua = ngaySua;
    }

    public SanPham() {
    }

    public int getSanPhamID() {
        return sanPhamID;
    }

    public void setSanPhamID(int sanPhamID) {
        this.sanPhamID = sanPhamID;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgaySua() {
        return ngaySua;
    }

    public void setNgaySua(Date ngaySua) {
        this.ngaySua = ngaySua;
    }
    
    
}
