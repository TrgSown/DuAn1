/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class HoaDon {
    private int hoaDonID;
    private String maHD;
    private String tenKH;
    private String sdt;
    private String diaChi;
    private double tongTien;
    private double tienShip;
    private double khachCanTra;
    private double tienThua;
    private String hinhThucThanhToan;
    private String trangThai;
    private Date ngayTao;
    private int nhanVienID;

    public HoaDon() {
    }

    public HoaDon(int hoaDonID, String maHD, String tenKH, String sdt, String diaChi, 
                  double tongTien, double tienShip, double khachCanTra, double tienThua,
                  String hinhThucThanhToan, String trangThai, Date ngayTao, int nhanVienID) {
        this.hoaDonID = hoaDonID;
        this.maHD = maHD;
        this.tenKH = tenKH;
        this.sdt = sdt;
        this.diaChi = diaChi;
        this.tongTien = tongTien;
        this.tienShip = tienShip;
        this.khachCanTra = khachCanTra;
        this.tienThua = tienThua;
        this.hinhThucThanhToan = hinhThucThanhToan;
        this.trangThai = trangThai;
        this.ngayTao = ngayTao;
        this.nhanVienID = nhanVienID;
    }

    // Getters and Setters
    public int getHoaDonID() {
        return hoaDonID;
    }

    public void setHoaDonID(int hoaDonID) {
        this.hoaDonID = hoaDonID;
    }

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getTenKH() {
        return tenKH;
    }

    public void setTenKH(String tenKH) {
        this.tenKH = tenKH;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getDiaChi() {
        return diaChi;
    }

    public void setDiaChi(String diaChi) {
        this.diaChi = diaChi;
    }

    public double getTongTien() {
        return tongTien;
    }

    public void setTongTien(double tongTien) {
        this.tongTien = tongTien;
    }

    public double getTienShip() {
        return tienShip;
    }

    public void setTienShip(double tienShip) {
        this.tienShip = tienShip;
    }

    public double getKhachCanTra() {
        return khachCanTra;
    }

    public void setKhachCanTra(double khachCanTra) {
        this.khachCanTra = khachCanTra;
    }

    public double getTienThua() {
        return tienThua;
    }

    public void setTienThua(double tienThua) {
        this.tienThua = tienThua;
    }

    public String getHinhThucThanhToan() {
        return hinhThucThanhToan;
    }

    public void setHinhThucThanhToan(String hinhThucThanhToan) {
        this.hinhThucThanhToan = hinhThucThanhToan;
    }

    public String getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(String trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public int getNhanVienID() {
        return nhanVienID;
    }

    public void setNhanVienID(int nhanVienID) {
        this.nhanVienID = nhanVienID;
    }
}
