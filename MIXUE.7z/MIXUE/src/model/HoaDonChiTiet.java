/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class HoaDonChiTiet {
    private int hoaDonChiTietID;
    private int hoaDonID;
    private int sanPhamChiTietID;
    private String tenSanPham;
    private int soLuong;
    private double donGia;
    private double thanhTien;
    private String ghiChu;

    public HoaDonChiTiet() {
    }

    public HoaDonChiTiet(int hoaDonChiTietID, int hoaDonID, int sanPhamChiTietID, 
                         String tenSanPham, int soLuong, double donGia, double thanhTien, String ghiChu) {
        this.hoaDonChiTietID = hoaDonChiTietID;
        this.hoaDonID = hoaDonID;
        this.sanPhamChiTietID = sanPhamChiTietID;
        this.tenSanPham = tenSanPham;
        this.soLuong = soLuong;
        this.donGia = donGia;
        this.thanhTien = thanhTien;
        this.ghiChu = ghiChu;
    }

    // Getters and Setters
    public int getHoaDonChiTietID() {
        return hoaDonChiTietID;
    }

    public void setHoaDonChiTietID(int hoaDonChiTietID) {
        this.hoaDonChiTietID = hoaDonChiTietID;
    }

    public int getHoaDonID() {
        return hoaDonID;
    }

    public void setHoaDonID(int hoaDonID) {
        this.hoaDonID = hoaDonID;
    }

    public int getSanPhamChiTietID() {
        return sanPhamChiTietID;
    }

    public void setSanPhamChiTietID(int sanPhamChiTietID) {
        this.sanPhamChiTietID = sanPhamChiTietID;
    }

    public String getTenSanPham() {
        return tenSanPham;
    }

    public void setTenSanPham(String tenSanPham) {
        this.tenSanPham = tenSanPham;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getDonGia() {
        return donGia;
    }

    public void setDonGia(double donGia) {
        this.donGia = donGia;
    }

    public double getThanhTien() {
        return thanhTien;
    }

    public void setThanhTien(double thanhTien) {
        this.thanhTien = thanhTien;
    }

    public String getGhiChu() {
        return ghiChu;
    }

    public void setGhiChu(String ghiChu) {
        this.ghiChu = ghiChu;
    }
    
    // Phương thức tính thành tiền
    public void calculateThanhTien() {
        this.thanhTien = this.soLuong * this.donGia;
    }
}
