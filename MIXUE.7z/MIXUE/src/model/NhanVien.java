/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ADMIN
 */
public class NhanVien {
    private int nhanVienID;
    private String maNV;
    private String tenNV;
    private String matKhau;
    private String chucVu; // "Admin" hoặc "NhanVien"
    private int trangThai;
    
    public NhanVien() {
    }

    public NhanVien(int nhanVienID, String maNV, String tenNV, String matKhau, String chucVu, int trangThai) {
        this.nhanVienID = nhanVienID;
        this.maNV = maNV;
        this.tenNV = tenNV;
        this.matKhau = matKhau;
        this.chucVu = chucVu;
        this.trangThai = trangThai;
    }

    public int getNhanVienID() {
        return nhanVienID;
    }

    public void setNhanVienID(int nhanVienID) {
        this.nhanVienID = nhanVienID;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getTenNV() {
        return tenNV;
    }

    public void setTenNV(String tenNV) {
        this.tenNV = tenNV;
    }

    public String getMatKhau() {
        return matKhau;
    }

    public void setMatKhau(String matKhau) {
        this.matKhau = matKhau;
    }

    public String getChucVu() {
        return chucVu;
    }

    public void setChucVu(String chucVu) {
        this.chucVu = chucVu;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }
    
    // Phương thức kiểm tra quyền admin
    public boolean isAdmin() {
        return "Admin".equalsIgnoreCase(this.chucVu);
    }
    
    // Phương thức kiểm tra quyền nhân viên
    public boolean isEmployee() {
        return "NhanVien".equalsIgnoreCase(this.chucVu);
    }
}
