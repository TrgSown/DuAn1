package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class ThuocTinh {
    private int thuocTinhID;
    private String tenThuocTinh;
    private String loaiThuocTinh; // "Kích thước", "Chất liệu", "Tên loại sản phẩm"
    private int trangThai;
    private Date ngayTao;
    private Date ngaySua;

    public ThuocTinh() {
    }

    public ThuocTinh(int thuocTinhID, String tenThuocTinh, String loaiThuocTinh, int trangThai, Date ngayTao, Date ngaySua) {
        this.thuocTinhID = thuocTinhID;
        this.tenThuocTinh = tenThuocTinh;
        this.loaiThuocTinh = loaiThuocTinh;
        this.trangThai = trangThai;
        this.ngayTao = ngayTao;
        this.ngaySua = ngaySua;
    }

    public int getThuocTinhID() {
        return thuocTinhID;
    }

    public void setThuocTinhID(int thuocTinhID) {
        this.thuocTinhID = thuocTinhID;
    }

    public String getTenThuocTinh() {
        return tenThuocTinh;
    }

    public void setTenThuocTinh(String tenThuocTinh) {
        this.tenThuocTinh = tenThuocTinh;
    }

    public String getLoaiThuocTinh() {
        return loaiThuocTinh;
    }

    public void setLoaiThuocTinh(String loaiThuocTinh) {
        this.loaiThuocTinh = loaiThuocTinh;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgaySua() {
        return ngaySua;
    }

    public void setNgaySua(Date ngaySua) {
        this.ngaySua = ngaySua;
    }
} 