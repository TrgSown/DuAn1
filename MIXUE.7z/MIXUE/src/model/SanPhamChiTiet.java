/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.Date;

/**
 *
 * @author ADMIN
 */
public class SanPhamChiTiet {
    private int sanPhamChiTietID;
    private String maSPCT;
    private String tenSP;
    private int soLuong;
    private double giaBan;
    private int trangThai;
    private String moTa;
    private Date ngayTao;
    private Date ngaySua;
    private int sanPhamID;
    private int chatLieuID;
    private int kichThuocID;

    public SanPhamChiTiet() {
    }

    public SanPhamChiTiet(int sanPhamChiTietID, String maSPCT, String tenSP, int soLuong, double giaBan, int trangThai, String moTa, Date ngayTao, Date ngaySua, int sanPhamID, int chatLieuID, int kichThuocID) {
        this.sanPhamChiTietID = sanPhamChiTietID;
        this.maSPCT = maSPCT;
        this.tenSP = tenSP;
        this.soLuong = soLuong;
        this.giaBan = giaBan;
        this.trangThai = trangThai;
        this.moTa = moTa;
        this.ngayTao = ngayTao;
        this.ngaySua = ngaySua;
        this.sanPhamID = sanPhamID;
        this.chatLieuID = chatLieuID;
        this.kichThuocID = kichThuocID;
    }

    public int getSanPhamChiTietID() {
        return sanPhamChiTietID;
    }

    public void setSanPhamChiTietID(int sanPhamChiTietID) {
        this.sanPhamChiTietID = sanPhamChiTietID;
    }

    public String getMaSPCT() {
        return maSPCT;
    }

    public void setMaSPCT(String maSPCT) {
        this.maSPCT = maSPCT;
    }

    public String getTenSP() {
        return tenSP;
    }

    public void setTenSP(String tenSP) {
        this.tenSP = tenSP;
    }

    public int getSoLuong() {
        return soLuong;
    }

    public void setSoLuong(int soLuong) {
        this.soLuong = soLuong;
    }

    public double getGiaBan() {
        return giaBan;
    }

    public void setGiaBan(double giaBan) {
        this.giaBan = giaBan;
    }

    public int getTrangThai() {
        return trangThai;
    }

    public void setTrangThai(int trangThai) {
        this.trangThai = trangThai;
    }

    public String getMoTa() {
        return moTa;
    }

    public void setMoTa(String moTa) {
        this.moTa = moTa;
    }

    public Date getNgayTao() {
        return ngayTao;
    }

    public void setNgayTao(Date ngayTao) {
        this.ngayTao = ngayTao;
    }

    public Date getNgaySua() {
        return ngaySua;
    }

    public void setNgaySua(Date ngaySua) {
        this.ngaySua = ngaySua;
    }

    public int getSanPhamID() {
        return sanPhamID;
    }

    public void setSanPhamID(int sanPhamID) {
        this.sanPhamID = sanPhamID;
    }

    public int getChatLieuID() {
        return chatLieuID;
    }

    public void setChatLieuID(int chatLieuID) {
        this.chatLieuID = chatLieuID;
    }

    public int getKichThuocID() {
        return kichThuocID;
    }

    public void setKichThuocID(int kichThuocID) {
        this.kichThuocID = kichThuocID;
    }

    
}
