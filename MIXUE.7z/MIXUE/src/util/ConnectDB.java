/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.io.IOException;
//import java.sql.*;

/**
 *
 * @author nthha
 */
public class ConnectDB {
    //TẠO CÁC THÔNG SỐ
    private static String SERVER = "localhost";
    private static String PATH = "1433";
    private static String DBNAME = "DuAn";//tên DB cần kết nối
    private static String USER = "sa";
    private static String PASS ="123";//pass của sv
    
    private static boolean SSL = true; //MẶC ĐỊNH KT KẾT NỐI SSL = TRUE
    private static String URL = null; //BIẾN CHƯA ĐƯỜNG LIÊN KẾT
    
    //THỰC HIỆN LOAD DRIVER + TẠO URL
    static {
        try {
            //1. Load Driver
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");            
            //2.1 Đối tượng chưa liên kết
            StringBuilder sbdURL = new StringBuilder();            
            sbdURL.append("jdbc:sqlserver://")
                    .append(SERVER).append(":").append(PATH).append(";")
                    .append("databasename = ").append(DBNAME).append(";")
                    .append("user = ").append(USER).append(";")
                    .append("password = ").append(PASS).append(";");            
            //2.2 Kiểm tra kết nối SSL
            //- thực hiện mã hóa DL và bỏ qua việc xác minh chứng chỉ
            if (SSL) {
                sbdURL.append("encrypt = true;trustServerCertificate = true");
            }            
            //2.3 Đưa liên kết vào chuỗi URL
            URL = sbdURL.toString();
            System.out.println("URL: "+URL);   
            
        } catch (Exception e) {
            System.out.println("Load Driver không thành công!");
        }
    }
    
    //THỰC HIỆN KẾT NỐI
    public static Connection getConnect(){
        try {
            return DriverManager.getConnection(URL);
        } catch (Exception e) {
            System.out.println("Kết nối không thành công!");
            return null;
        }
    }
    
    public static void main(String[] args) throws SQLException {
        //Thực hiện kết nối
        Connection conn = ConnectDB.getConnect();
        
        //Lấy thông tin DB
        DatabaseMetaData data = conn.getMetaData();
        
        //Hiển thị thông tin
        System.out.println("Tên JDBC: "+data.getDriverName());
        System.out.println("Phiên bản JDBC: "+data.getDriverVersion());
        System.out.println("Tên CSDL: "+data.getDatabaseProductName());
        System.out.println("Phiên bản CSDL: "+data.getDatabaseProductVersion());
    }
}
