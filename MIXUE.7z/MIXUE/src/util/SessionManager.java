/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package util;

import model.NhanVien;

/**
 * Quản lý phiên đăng nhập và quyền người dùng
 * @author ADMIN
 */
public class SessionManager {
    private static NhanVien currentUser = null;
    
    // Đăng nhập và lưu thông tin người dùng
    public static void login(NhanVien user) {
        currentUser = user;
    }
    
    // Đăng xuất
    public static void logout() {
        currentUser = null;
    }
    
    // Lấy thông tin người dùng hiện tại
    public static NhanVien getCurrentUser() {
        return currentUser;
    }
    
    // Kiểm tra có đăng nhập hay không
    public static boolean isLoggedIn() {
        return currentUser != null;
    }
    
    // Kiểm tra quyền Admin
    public static boolean isAdmin() {
        return currentUser != null && currentUser.isAdmin();
    }
    
    // Kiểm tra quyền Nhân viên
    public static boolean isEmployee() {
        return currentUser != null && currentUser.isEmployee();
    }
    
    // Lấy tên người dùng hiện tại
    public static String getCurrentUserName() {
        return currentUser != null ? currentUser.getTenNV() : "Unknown";
    }
    
    // Lấy mã nhân viên hiện tại
    public static String getCurrentUserCode() {
        return currentUser != null ? currentUser.getMaNV() : "Unknown";
    }
    
    // Lấy chức vụ hiện tại
    public static String getCurrentUserRole() {
        return currentUser != null ? currentUser.getChucVu() : "Unknown";
    }
}
